let questions = [
  {
    numb: 1,
    question: ")এটা কত তম বিসিএস পরিক্ষার টেস্ট?:",
    answer: "(খ) ৩৭ তম",
    options: [
    "(ক) ৩৫ তম",
    "(খ) ৩৭ তম",
    "(গ) ৩৬ তম",
    "(ঘ) ৩২ তম"
    ]
},

//heare is all questins


];