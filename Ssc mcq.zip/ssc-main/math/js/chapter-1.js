let questions = [
  {
    numb: 1,
    question: "বাংলাদেশ ওর রাজধানির নাম কি?:",
    answer: "(খ) ঢাকা",
    options: [
    "(ক) কুমিল্লা",
    "(খ) ঢাকা",
    "(গ) খুলনা",
    "(ঘ) চট্রগ্রাম"
    ]
},

//heare is all questins


];